export interface Register {
    email: string;
    password: string;
    // firstname: string;
    // lastname: string;
    // age: number;
}

export interface Usuario {
    email: string;
    password: string;
}
